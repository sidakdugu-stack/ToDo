from .routers import router as teams_router

__all__ = ["teams_router"]